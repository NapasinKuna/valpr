from distutils.core import setup

setup(
    name='VALPR',
    version='0.1dev',
    packages=['vlpr',],
    license='Verily Vision co.,ltd. for testing VALPR system license',
    long_description=open('README.txt').read(),
)