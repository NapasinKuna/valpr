This project is Verily Vision Automatic License Plate Recognition system
engine create for Commercial use version,0.1. 